

CREATE DATABASE personas
DEFAULT CHARACTER SET latin1
DEFAULT COLLATE latin1_swedish_ci;

use personas;

CREATE TABLE datos_personas (
  id int(11) AUTO_INCREMENT,
  nombre varchar(40),
  apellido varchar(40),
  edad tinyint(2),
  fecha timestamp DEFAULT CURRENT_TIMESTAMP,
  provincia varchar(30),
  PRIMARY KEY (id)
);

INSERT INTO datos_personas (nombre, apellido, edad, provincia)
VALUES ('Juan', 'González', 28, 'Buenos Aires');

INSERT INTO datos_personas (nombre, apellido, edad, provincia)
VALUES ('María', 'Rodríguez', 35, 'Córdoba');

INSERT INTO datos_personas (nombre, apellido, edad, provincia)
VALUES ('Carlos', 'Fernández', 42, 'Santa Fe');

INSERT INTO datos_personas (nombre, apellido, edad, provincia)
VALUES ('Ana', 'López', 30, 'Mendoza');

INSERT INTO datos_personas (nombre, apellido, edad, provincia)
VALUES ('Pedro', 'Martínez', 25, 'Salta');

SELECT * FROM datos_personas;



